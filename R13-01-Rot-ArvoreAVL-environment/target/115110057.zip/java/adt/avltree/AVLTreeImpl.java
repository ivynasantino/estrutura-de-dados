package adt.avltree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;
import adt.bt.Util;

/**
 * 
 * Performs consistency validations within a AVL Tree instance
 * 
 * @author Claudio Campelo
 *
 * @param <T>
 */
public class AVLTreeImpl<T extends Comparable<T>> extends BSTImpl<T> implements
		AVLTree<T> {

	// TODO Do not forget: you must override the methods insert and remove
	// conveniently.

	// AUXILIARY
	protected int calculateBalance(BSTNode<T> node) {
		int heightLeft = height((BSTNode<T>)node.getLeft());
		int heightRight = height((BSTNode<T>)node.getRight());
		
		return Math.abs(heightLeft - heightRight);
	}

	// AUXILIARY
	protected void rebalance(BSTNode<T> node) {
		if (node == null || node.isEmpty()) return;
		
		BSTNode<T> rotacionNode = rotacion(node);
		
		if (rotacionNode.getParent() == null) {
			root = rotacionNode;
		}
	}
	
	private BSTNode<T> rotacion(BSTNode<T> node) {
		int heightLeft = height((BSTNode<T>)node.getLeft());
		int heightRight = height((BSTNode<T>)node.getRight());
		
		int balance = heightLeft - heightRight;
		
		if (balance > ZERO) {
			int heightChildLeft = height((BSTNode<T>)node.getLeft().getLeft());
			int heightChildRight = height((BSTNode<T>)node.getLeft().getRight());
		
			int balanceChild = heightChildLeft - heightChildRight;
			
			if (balanceChild < ZERO) {
				Util.leftRotation((BSTNode<T>)node.getLeft());
				return Util.rightRotation(node);
				
			} else {
				return Util.rightRotation(node);
			}
		} else {
			int heightChildRight = height((BSTNode<T>)node.getRight().getRight());
			int heightChildLeft = height((BSTNode<T>)node.getRight().getLeft());
			
			int balanceChild = heightChildLeft - heightChildRight;
			
			if (balanceChild > ZERO) {
				Util.rightRotation((BSTNode<T>)node.getRight());
				return Util.leftRotation(node);
				
			} else {
				return Util.leftRotation(node);
			}
		}
	}

	// AUXILIARY
	protected void rebalanceUp(BSTNode<T> node) {
		if (node == null) return;
		
		if (calculateBalance(node) > ONE) {
			rebalance(node);
		}
		
		rebalanceUp((BSTNode<T>)node.getParent());
	}
	
	public void insert(T element) {
		if (element == null) return;
		insert(root, element);
	}
	
	private void insert(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
			
			rebalanceUp(node);
			return;
			
		} else if (element.compareTo(node.getData()) > ZERO) {
			insert((BSTNode<T>)node.getRight(), element);
			
		} else if (element.compareTo(node.getData()) < ZERO) {
			insert((BSTNode<T>)node.getLeft(), element);
		}
	}
	
	public void remove(T element) {
		if (element == null) return;
		
		BSTNode<T> node = search(element);
		
		if (node == null) return;
		
		int degree = degree(node);
		
		if (degree == ZERO) { //Leaf
			removeLeaf(node);
		} else if (degree == ONE) {
			removeOneDegree(node);
		} else if (degree == TWO){
			removeTwoDegrees(node);
		} else {
			return;
		}
	}
	
	private void removeLeaf(BSTNode<T> node) {
		node.setData(null);
		rebalanceUp(node);
	}
	
	private void removeOneDegree(BSTNode<T> node) {
		if (node.getParent() == null) { //Root
			if (!node.getLeft().isEmpty()) {
				node.getLeft().setParent(null);
				root = (BSTNode<T>) node.getLeft();
				rebalanceUp(root);
				return;
				
			} else {
				node.getRight().setParent(null);
				root = (BSTNode<T>) node.getRight();
				rebalanceUp(root);
				return;
			}
		} 
		
		BSTNode<T> nodeAux = null;
			
		if (!node.getRight().isEmpty()) {
			nodeAux = (BSTNode<T>) node.getRight();
		} else {
			nodeAux = (BSTNode<T>) node.getLeft();
		}
			
		nodeAux.setParent(node.getParent());
			
		if (node.equals(node.getParent().getLeft())) {
			node.getParent().setLeft(nodeAux);
		
		} else if (node.equals(node.getParent().getRight())){
			node.getParent().setRight(nodeAux);
		}
		
		rebalanceUp(nodeAux);
	}
	
	private void removeTwoDegrees(BSTNode<T> node) {
		BSTNode<T> sucessor = sucessor(node.getData());
		
		if (sucessor == null) return;
		
		int degree = degree(sucessor);
		node.setData(sucessor.getData());
		
		if (degree == ZERO) {
			removeLeaf(sucessor);
		} else if (degree == ONE) {
			removeOneDegree(sucessor);
		} else {
			removeTwoDegrees(sucessor);
		}
	}
}
