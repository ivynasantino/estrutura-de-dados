package adt.bt;

import adt.bst.BSTNode;

public class Util {


	/**
	 * A rotacao a esquerda em node deve subir e retornar seu filho a direita
	 * @param node
	 * @return
	 */
	public static <T extends Comparable<T>> BSTNode<T> leftRotation(BSTNode<T> node) {
		BSTNode<T> rightSon = (BSTNode<T>) node.getRight();
		
		rightSon.setParent(node.getParent());
		
		if (rightSon.getParent() != null) {
			if(node.getParent().getRight().equals(node)) {
				node.getParent().setLeft(rightSon);
			}else {
				node.getParent().setLeft(rightSon);
			}
		}
		
		node.setRight(rightSon.getLeft());
		rightSon.getLeft().setParent(node);
		rightSon.setLeft(node);
		node.setParent(rightSon);
		
		return rightSon;
	}

	/**
	 * A rotacao a direita em node deve subir e retornar seu filho a esquerda
	 * @param node
	 * @return
	 */
	public static <T extends Comparable<T>> BSTNode<T> rightRotation(BSTNode<T> node) {
		BSTNode<T> leftSon = (BSTNode<T>) node.getLeft();
		
		leftSon.setParent(node.getParent());
		
		if (leftSon.getParent() != null) {
			if(node.getParent().getLeft().equals(node)) {
				node.getParent().setLeft(leftSon);
			}else {
				node.getParent().setRight(leftSon);
			}
		}
		
		node.setLeft(leftSon.getRight());
		leftSon.getRight().setParent(node);
		leftSon.setRight(node);
		node.setParent(leftSon);
		
		return leftSon;
	}

	public static <T extends Comparable<T>> T[] makeArrayOfComparable(int size) {
		@SuppressWarnings("unchecked")
		T[] array = (T[]) new Comparable[size];
		return array;
	}
}
